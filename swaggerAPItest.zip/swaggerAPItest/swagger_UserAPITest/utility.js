var chai = require("chai");
var chaihttp = require("chai-http");
var expect = require("chai").expect;
const asserttype = require('chai-asserttype');
var dataSchema  = require('./jsonSchema.js');
var postData  = require('./apiPostData.js');

chai.use(chaihttp);
chai.use(require('chai-json-schema'));

chai.use(asserttype);
var baseURL  = "http://localhost:8080/api/v3";

exports.createUser = 
        chai.request(baseURL)
            .post('/user')
            .send(postData.testCreateUserData)
            .end(function(err, res){
                console.log("A new User is created")
       })

       exports.deleteUser  = 
       chai.request(baseURL)
            .del('/user/theUser')
            .end(function(err, res){
                console.log("The User is Deleted")
 
      })       




