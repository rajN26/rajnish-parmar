var chai = require("chai");
var chaihttp = require("chai-http");
var expect = require("chai").expect;
const asserttype = require('chai-asserttype');
var dataSchema  = require('./pet_jsonSchema.js');
var postData  = require('./Swagger_PetApiPostData.js');
//var utilFunctions  = require('./utility.js');


chai.use(chaihttp);
chai.use(require('chai-json-schema'));

chai.use(asserttype);
var baseURL  = "http://localhost:8080/api/v3";

describe("API tests for swagger ", function(){

    it("Verify the POST response for add new pet ", function(done){
        chai.request(baseURL)
        .post('/pet')
        .send(postData.addNewPetData)
        .end(function(err,res){
            console.log(res.body)
            expect(res.statusCode).to.equal(200);
            expect(res.body).to.be.jsonSchema(dataSchema.addNewPeteSchema);
            done();
        })
    })


    it("Verify the POST response for a Pet details update ", function(done){
        chai.request(baseURL)
        .post('/pet/'+postData.updatePetsData.petId)
        .query({name: postData.updatePetsData.name,
               status : postData.updatePetsData.status.available})
        .end(function(err,res){
            console.log(res.body)
            expect(res.statusCode).to.equal(200);
            expect(res.body).to.be.jsonSchema(dataSchema.petUpdateSchema);
            done();
        })
    })

    
});

