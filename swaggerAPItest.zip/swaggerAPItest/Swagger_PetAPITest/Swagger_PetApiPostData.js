exports.updatePetsData = 
{
    petId : 10,
    name : 'rabbit',
    status:{
        available : 'available',
        pending : 'pending',
        sold    :  'sold' 
    } 
}

exports.addNewPetData = {
    "id": 100000,
    "name": "ffd",
    "category": {
      "id": 4,
      "name": "Dogs"
    },
    "photoUrls": [
      "https://i.ytimg.com/vi/MPV2METPeJU/maxresdefault.jpg"
    ],
    "tags": [
      {
        "id": 0,
        "name": "string"
      }
    ],
    "status": "available"
  }
