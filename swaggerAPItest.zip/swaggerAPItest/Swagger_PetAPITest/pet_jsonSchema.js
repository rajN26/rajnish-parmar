exports.addNewPeteSchema ={
    "$schema": "http://json-schema.org/draft-07/schema",
    "$id": "http://example.com/example.json",
    "type": "object",
    "title": "The root schema",
    "description": "The root schema comprises the entire JSON document.",
    "default": {},
    "examples": [
        {
            "id": 100000,
            "name": "ffd",
            "category": {
                "id": 4,
                "name": "Dogs"
            },
            "photoUrls": [
                "https://i.ytimg.com/vi/MPV2METPeJU/maxresdefault.jpg"
            ],
            "tags": [
                {
                    "id": 0,
                    "name": "string"
                }
            ],
            "status": "available"
        }
    ],
    "required": [
        "id",
        "name",
        "category",
        "photoUrls",
        "tags",
        "status"
    ],
    "properties": {
        "id": {
            "$id": "#/properties/id",
            "type": "integer",
            "title": "The id schema",
            "description": "An explanation about the purpose of this instance.",
            "default": 0,
            "examples": [
                100000
            ]
        },
        "name": {
            "$id": "#/properties/name",
            "type": "string",
            "title": "The name schema",
            "description": "An explanation about the purpose of this instance.",
            "default": "",
            "examples": [
                "ffd"
            ]
        },
        "category": {
            "$id": "#/properties/category",
            "type": "object",
            "title": "The category schema",
            "description": "An explanation about the purpose of this instance.",
            "default": {},
            "examples": [
                {
                    "id": 4,
                    "name": "Dogs"
                }
            ],
            "required": [
                "id",
                "name"
            ],
            "properties": {
                "id": {
                    "$id": "#/properties/category/properties/id",
                    "type": "integer",
                    "title": "The id schema",
                    "description": "An explanation about the purpose of this instance.",
                    "default": 0,
                    "examples": [
                        4
                    ]
                },
                "name": {
                    "$id": "#/properties/category/properties/name",
                    "type": "string",
                    "title": "The name schema",
                    "description": "An explanation about the purpose of this instance.",
                    "default": "",
                    "examples": [
                        "Dogs"
                    ]
                }
            },
            "additionalProperties": true
        },
        "photoUrls": {
            "$id": "#/properties/photoUrls",
            "type": "array",
            "title": "The photoUrls schema",
            "description": "An explanation about the purpose of this instance.",
            "default": [],
            "examples": [
                [
                    "https://i.ytimg.com/vi/MPV2METPeJU/maxresdefault.jpg"
                ]
            ],
            "additionalItems": true,
            "items": {
                "$id": "#/properties/photoUrls/items",
                "anyOf": [
                    {
                        "$id": "#/properties/photoUrls/items/anyOf/0",
                        "type": "string",
                        "title": "The first anyOf schema",
                        "description": "An explanation about the purpose of this instance.",
                        "default": "",
                        "examples": [
                            "https://i.ytimg.com/vi/MPV2METPeJU/maxresdefault.jpg"
                        ]
                    }
                ]
            }
        },
        "tags": {
            "$id": "#/properties/tags",
            "type": "array",
            "title": "The tags schema",
            "description": "An explanation about the purpose of this instance.",
            "default": [],
            "examples": [
                [
                    {
                        "id": 0,
                        "name": "string"
                    }
                ]
            ],
            "additionalItems": true,
            "items": {
                "$id": "#/properties/tags/items",
                "anyOf": [
                    {
                        "$id": "#/properties/tags/items/anyOf/0",
                        "type": "object",
                        "title": "The first anyOf schema",
                        "description": "An explanation about the purpose of this instance.",
                        "default": {},
                        "examples": [
                            {
                                "id": 0,
                                "name": "string"
                            }
                        ],
                        "required": [
                            "id",
                            "name"
                        ],
                        "properties": {
                            "id": {
                                "$id": "#/properties/tags/items/anyOf/0/properties/id",
                                "type": "integer",
                                "title": "The id schema",
                                "description": "An explanation about the purpose of this instance.",
                                "default": 0,
                                "examples": [
                                    0
                                ]
                            },
                            "name": {
                                "$id": "#/properties/tags/items/anyOf/0/properties/name",
                                "type": "string",
                                "title": "The name schema",
                                "description": "An explanation about the purpose of this instance.",
                                "default": "",
                                "examples": [
                                    "string"
                                ]
                            }
                        },
                        "additionalProperties": true
                    }
                ]
            }
        },
        "status": {
            "$id": "#/properties/status",
            "type": "string",
            "title": "The status schema",
            "description": "An explanation about the purpose of this instance.",
            "default": "",
            "examples": [
                "available"
            ]
        }
    },
    "additionalProperties": true
}


exports.petUpdateSchema = {
    "$schema": "http://json-schema.org/draft-07/schema",
    "$id": "http://example.com/example.json",
    "type": "object",
    "title": "The root schema",
    "description": "The root schema comprises the entire JSON document.",
    "default": {},
    "examples": [
        {
            "id": 10,
            "category": {
                "id": 3,
                "name": "Rabbits"
            },
            "name": "rabbit",
            "photoUrls": [
                "url1",
                "url2"
            ],
            "tags": [
                {
                    "id": 1,
                    "name": "tag3"
                },
                {
                    "id": 2,
                    "name": "tag4"
                }
            ],
            "status": "available"
        }
    ],
    "required": [
        "id",
        "category",
        "name",
        "photoUrls",
        "tags",
        "status"
    ],
    "properties": {
        "id": {
            "$id": "#/properties/id",
            "type": "integer",
            "title": "The id schema",
            "description": "An explanation about the purpose of this instance.",
            "default": 0,
            "examples": [
                10
            ]
        },
        "category": {
            "$id": "#/properties/category",
            "type": "object",
            "title": "The category schema",
            "description": "An explanation about the purpose of this instance.",
            "default": {},
            "examples": [
                {
                    "id": 3,
                    "name": "Rabbits"
                }
            ],
            "required": [
                "id",
                "name"
            ],
            "properties": {
                "id": {
                    "$id": "#/properties/category/properties/id",
                    "type": "integer",
                    "title": "The id schema",
                    "description": "An explanation about the purpose of this instance.",
                    "default": 0,
                    "examples": [
                        3
                    ]
                },
                "name": {
                    "$id": "#/properties/category/properties/name",
                    "type": "string",
                    "title": "The name schema",
                    "description": "An explanation about the purpose of this instance.",
                    "default": "",
                    "examples": [
                        "Rabbits"
                    ]
                }
            },
            "additionalProperties": true
        },
        "name": {
            "$id": "#/properties/name",
            "type": "string",
            "title": "The name schema",
            "description": "An explanation about the purpose of this instance.",
            "default": "",
            "examples": [
                "rabbit"
            ]
        },
        "photoUrls": {
            "$id": "#/properties/photoUrls",
            "type": "array",
            "title": "The photoUrls schema",
            "description": "An explanation about the purpose of this instance.",
            "default": [],
            "examples": [
                [
                    "url1",
                    "url2"
                ]
            ],
            "additionalItems": true,
            "items": {
                "$id": "#/properties/photoUrls/items",
                "anyOf": [
                    {
                        "$id": "#/properties/photoUrls/items/anyOf/0",
                        "type": "string",
                        "title": "The first anyOf schema",
                        "description": "An explanation about the purpose of this instance.",
                        "default": "",
                        "examples": [
                            "url1",
                            "url2"
                        ]
                    }
                ]
            }
        },
        "tags": {
            "$id": "#/properties/tags",
            "type": "array",
            "title": "The tags schema",
            "description": "An explanation about the purpose of this instance.",
            "default": [],
            "examples": [
                [
                    {
                        "id": 1,
                        "name": "tag3"
                    },
                    {
                        "id": 2,
                        "name": "tag4"
                    }
                ]
            ],
            "additionalItems": true,
            "items": {
                "$id": "#/properties/tags/items",
                "anyOf": [
                    {
                        "$id": "#/properties/tags/items/anyOf/0",
                        "type": "object",
                        "title": "The first anyOf schema",
                        "description": "An explanation about the purpose of this instance.",
                        "default": {},
                        "examples": [
                            {
                                "id": 1,
                                "name": "tag3"
                            }
                        ],
                        "required": [
                            "id",
                            "name"
                        ],
                        "properties": {
                            "id": {
                                "$id": "#/properties/tags/items/anyOf/0/properties/id",
                                "type": "integer",
                                "title": "The id schema",
                                "description": "An explanation about the purpose of this instance.",
                                "default": 0,
                                "examples": [
                                    1
                                ]
                            },
                            "name": {
                                "$id": "#/properties/tags/items/anyOf/0/properties/name",
                                "type": "string",
                                "title": "The name schema",
                                "description": "An explanation about the purpose of this instance.",
                                "default": "",
                                "examples": [
                                    "tag3"
                                ]
                            }
                        },
                        "additionalProperties": true
                    }
                ]
            }
        },
        "status": {
            "$id": "#/properties/status",
            "type": "string",
            "title": "The status schema",
            "description": "An explanation about the purpose of this instance.",
            "default": "",
            "examples": [
                "available"
            ]
        }
    },
    "additionalProperties": true
}