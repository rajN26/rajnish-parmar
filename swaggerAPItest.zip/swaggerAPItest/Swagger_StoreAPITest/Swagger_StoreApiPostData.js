const shipDate = new Date();

exports.testPetOrderData = 
{
  "id": 10,
  "petId": 198772,
  "quantity": 7,
  "shipDate": shipDate.toISOString(),
  "status": "approved",
  "complete": true
}

exports.testOrderIDs = [5,1,10,100];




