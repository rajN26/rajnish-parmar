exports.getInventory = {
    "$schema": "http://json-schema.org/draft-07/schema",
    "$id": "http://example.com/example.json",
    "type": "object",
    "title": "The root schema",
    "description": "The root schema comprises the entire JSON document.",
    "default": {},
    "examples": [
        {
            "approved": 50,
            "placed": 100,
            "delivered": 50
        }
    ],
    "required": [
        "approved",
        "placed",
        "delivered"
    ],
    "properties": {
        "approved": {
            "$id": "#/properties/approved",
            "type": "integer",
            "title": "The approved schema",
            "description": "An explanation about the purpose of this instance.",
            "default": 0,
            "examples": [
                50
            ]
        },
        "placed": {
            "$id": "#/properties/placed",
            "type": "integer",
            "title": "The placed schema",
            "description": "An explanation about the purpose of this instance.",
            "default": 0,
            "examples": [
                100
            ]
        },
        "delivered": {
            "$id": "#/properties/delivered",
            "type": "integer",
            "title": "The delivered schema",
            "description": "An explanation about the purpose of this instance.",
            "default": 0,
            "examples": [
                50
            ]
        }
    },
    "additionalProperties": true
}

exports.petOrder = {
    "$schema": "http://json-schema.org/draft-07/schema",
    "$id": "http://example.com/example.json",
    "type": "object",
    "title": "The root schema",
    "description": "The root schema comprises the entire JSON document.",
    "default": {},
    "examples": [
        {
            "id": 10,
            "petId": 198772,
            "quantity": 7,
            "shipDate": "2021-02-28T23:21:43.302Z",
            "status": "approved",
            "complete": true
        }
    ],
    "required": [
        "id",
        "petId",
        "quantity",
        "shipDate",
        "status",
        "complete"
    ],
    "properties": {
        "id": {
            "$id": "#/properties/id",
            "type": "integer",
            "title": "The id schema",
            "description": "An explanation about the purpose of this instance.",
            "default": 0,
            "examples": [
                10
            ]
        },
        "petId": {
            "$id": "#/properties/petId",
            "type": "integer",
            "title": "The petId schema",
            "description": "An explanation about the purpose of this instance.",
            "default": 0,
            "examples": [
                198772
            ]
        },
        "quantity": {
            "$id": "#/properties/quantity",
            "type": "integer",
            "title": "The quantity schema",
            "description": "An explanation about the purpose of this instance.",
            "default": 0,
            "examples": [
                7
            ]
        },
        "shipDate": {
            "$id": "#/properties/shipDate",
            "type": "string",
            "title": "The shipDate schema",
            "description": "An explanation about the purpose of this instance.",
            "default": "",
            "examples": [
                "2021-02-28T23:21:43.302Z"
            ]
        },
        "status": {
            "$id": "#/properties/status",
            "type": "string",
            "title": "The status schema",
            "description": "An explanation about the purpose of this instance.",
            "default": "",
            "examples": [
                "approved"
            ]
        },
        "complete": {
            "$id": "#/properties/complete",
            "type": "boolean",
            "title": "The complete schema",
            "description": "An explanation about the purpose of this instance.",
            "default": false,
            "examples": [
                true
            ]
        }
    },
    "additionalProperties": true
}