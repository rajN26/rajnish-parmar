var chai = require("chai");
var chaihttp = require("chai-http");
var expect = require("chai").expect;
const asserttype = require('chai-asserttype');
var dataSchema  = require('./store_jsonSchema.js');
var postData  = require('./Swagger_StoreApiPostData.js');
//var utilFunctions  = require('./utility.js');


chai.use(chaihttp);
chai.use(require('chai-json-schema'));

chai.use(asserttype);
var baseURL  = "http://localhost:8080/api/v3";

describe("API tests for swagger ", function(){
 it("Verify the GET response for '/store/inventory' route has expected properties ", function(done){
        chai.request(baseURL)
        .get('/store/inventory')
        .end(function(err,res){
            console.log(res.body)
            expect(res.body).to.have.property('approved').to.be.an('number');
            expect(res.body).to.have.property('placed').to.be.an('number');
            expect(res.body).to.have.property('delivered').to.be.an('number');
             if(err){
                done(err);
                }
             done();
        })
    })

    it("Verify the POST response for a Pet Order ", function(done){
        chai.request(baseURL)
        .post('/store/order')
        .send(postData.testPetOrderData)
        .end(function(err,res){
            console.log(res.body)
            expect(res.statusCode).to.equal(200);
            expect(res.body).to.be.jsonSchema(dataSchema.petOrder);
             if(err){
                done(err);
                }
             done();
        })
    })

    it("Verify the GET response for purchase order by ID  ", function(done){
        for(let i = 0 ; i < postData.testOrderIDs.length; i++)
        {
        chai.request(baseURL)
        .get('/store/order/'+postData.testOrderIDs[i])
        .end(function(err,res){
            if(postData.testOrderIDs[i] >= 5 && postData.testOrderIDs[i] >10)
            {
                expect(res.statusCode).to.equal(200);

            }

            else if (postData.testOrderIDs[i] < 5)
            {
                expect(res.statusCode).to.equal(404);
            }
        })
         
    }
    done();
    })



           





  


});