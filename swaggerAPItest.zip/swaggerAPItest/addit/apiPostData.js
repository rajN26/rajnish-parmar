exports.testCreateUserData = {
        "id": 11,
        "username": "theUser2",
        "firstName": "John",
        "lastName": "James",
        "email": "joh111n@email.com",
        "password": "12345",
        "phone": "12345",
        "userStatus": 1
      }

 exports.testCreateUserListData = [{
        "id": 100,
        "username": "theUserxy",
        "firstName": "John",
        "lastName": "James",
        "email": "johnaa@email.com",
        "password": "12345",
        "phone": "12345",
        "userStatus": 1
      },
      {
        "id": 101,
        "username": "theUserab",
        "firstName": "John",
        "lastName": "James",
        "email": "johxx@email.com",
        "password": "12345",
        "phone": "12345",
        "userStatus": 1
      }

    ]


