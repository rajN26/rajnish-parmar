var chai = require("chai");
var chaihttp = require("chai-http");
var expect = require("chai").expect;
const asserttype = require('chai-asserttype');
var dataSchema  = require('./jsonSchema.js');
var postData  = require('./apiPostData.js');
var utilFunctions  = require('../utility.js');


chai.use(chaihttp);
chai.use(require('chai-json-schema'));

chai.use(asserttype);
var baseURL  = "http://localhost:8080/api/v3";

describe("API tests for swagger ", function(){
 
    it("Verify user is created successfully", function(done){
        chai.request(baseURL)
            .post('/user')
            .send(postData.testCreateUserData)
            .end(function(err, res){
               console.log(res.body)
               expect(res.statusCode).to.equal(200);
               expect(res.body).to.be.jsonSchema(dataSchema.jsonSchemaUser);
               if(err){
                done(err);
                }
            done();
            })

    })

    it("Verify user List is created successfully", function(done){
        chai.request(baseURL)
            .post('/user/createWithList')
            .send(postData.testCreateUserListData)
            .end(function(err, res){
               console.log(res.body)
               expect(res.statusCode).to.equal(200);
               expect(res.body).to.be.jsonSchema(dataSchema.jsonSchemaUser);
               if(err){
                done(err);
                }
            done();
            })

    })

     it("Verify the GET response follows json schema for '/user/{username}' route ", function(done){
        chai.request(baseURL)
        .get('/user/user1')
        .end(function(err,res){
            console.log(res.body)
            expect(res.body).to.be.jsonSchema(dataSchema.jsonSchemaUser);
            if(err){
                done(err);
                }
            done();
        })
    })

        it("Verify user is able to login successfully ", function(done){
            utilFunctions.createUser;
            chai.request(baseURL)
                .get('/user/login')
                .query({username: 'user1', password: 12345})
                .end(function(err,res){
                expect(res.body).to.be.jsonSchema(dataSchema.jsonSchemaUser);
                 
        })
         utilFunctions.deleteUser;

         done();


    })


  


});